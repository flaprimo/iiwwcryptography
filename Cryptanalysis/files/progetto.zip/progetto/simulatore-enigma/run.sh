#!/bin/bash
java -jar Cryptography.jar &
exit

