#!/bin/bash
java -jar Cryptanalysis.jar &
exit
